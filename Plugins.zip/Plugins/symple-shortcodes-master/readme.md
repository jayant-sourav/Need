# Symple Shortcodes WordPress Plugin

A free Shortcodes plugin created by WPExplorer. Learn more here: http://www.wpexplorer.com/symple-shortcodes/