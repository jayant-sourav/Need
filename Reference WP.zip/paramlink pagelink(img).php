<img src="<?php echo get_field('image1'); ?>" alt="<?php echo get_field('title'); ?>" http://dev.synex.tech/asia/project/project-2-2-2-2-2/






http://dev.synex.tech/asia/project/project-2-2-2-2-2/
