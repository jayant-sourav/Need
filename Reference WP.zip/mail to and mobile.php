
// mobile & mail dynamic



<li>
  <span><img src="<?php echo get_template_directory_uri();?>/images/phone-2.png" alt="<?php echo get_bloginfo( 'name' ); ?> - Phone">
  </span>
  <small><a href="tel:+49016093337281">+ 49 (0) 160 / 93337 281</a></small>
</li>


<li>
  <span>
    <img src="<?php echo get_template_directory_uri();?>/images/mail.png" alt="<?php echo get_bloginfo( 'name' ); ?> - Email">
  </span>
    <small>
      <a href="mailto:info@dm-schmierstoffservice.de">info@dm-schmierstoffservice.de</a>
    </small>
</li>
