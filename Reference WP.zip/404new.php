<?php get_header() ?>
<div class="banner-image" style="background-image:url(<?php bloginfo('template_url'); ?>images/our-project-banner.jpg">

<h1>404</h1>
</div>
<div class="container">
<div class="rates">
<h1>404</h1>

</div>
										<h1>Opps! Looks like you may have taken a wrong turn. Don't worry it happens to the best of us.</h1>

<a href="<?php echo get_settings('home'); ?>" class="gotohome">GO BACK TO THE HOME PAGE</a>

</div>
<?php get_footer() ?>
