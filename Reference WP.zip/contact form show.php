
//contact form short code //


  <?php echo do_shortcode('[contact-form-7 id="96" title="Contact form 1"]'); ?>
