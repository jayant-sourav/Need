

1.
//Gives the name of Website, parameter can be diffrent.

 <?php bloginfo('name'); ?>   


2.
 //Gives the name of tagline of website

 <?php bloginfo('description'); ?>


 3.
 // Wp function, keeps track of which post you are currently working on, Each time
 	while loop run it will tell WP to get all relevent information about next post ready for us to use.

 			while(have_posts()){

 			the_post();


 		}

 4.
// Slug of the page with the link refering to individual POST/PAGE.

 		<a href= "<?php the_permalink(); ?>">


 5. 

 //Show the title of the blog post.


 		<?php the_title(); ?>



 6.
 // Show the content of the blog post.

 	<?php the_content(); ?>



7.
// Get the content of the header.php

		<?php get_header(); ?>


8.  Get the content of the footer.php


		<?php get_footer(); ?>

9.	Load all the CSS, JS from the function.php, included in head section.


		<?php wp_head(); ?>

10.  Show the admin bar at the top label of screen, included in footer.php


		<?php wp_footer(); ?>




11.
//Load CSS file from style.css

	wp_enqueue_style('user-defined-name', get_stylesheet_uri());



	add_action('wp_enqueue_scripts', 'userdefined-function-name');



12. Putting font link in function.php

	wp_enqueue_style('user-defined-name', '//maxcdn.......    .css');



13. Putting font link in function.php

	wp_enqueue_style('user-defined-name', '//font.......    700i');



14.  Givning url to image folder


	<div class="page-banner_bg_image"  style= "backgroung-image: 
	url(<?php echo get_theme_file_uri('/images/banner.jpg') ?>);"></div>

15.

//Loading JS file


	wp_enqueue_script('user-defined-name', get_theme_file_uri('/js/script-buldled.js'), NULL, 1.0, true);



16.
 //Avoiding JS, CSS file from Caching


 			wp_enqueue_script('user-defined-name', get_theme_file_uri('/js/script-buldled.js'), NULL, microtime(), true);



			wp_enqueue_style('user-defined-name', get_stylesheet_uri(),NULL,mocrotime());



17.

//Generating Current Title tag on browser tab

			
			add_theme_support('title-tag');


			add_action('after_setup_theme', 'userdefined-function-name')


18. 
//Adding link to the menu eg. About Us Page.


	<a href="<?php echo site_url('/about-us') ?>">About US</a>

19.
// Adding link to logo or any content to home page


	<a href="<?php echo site_url() ?>"> Home </a>


20.
// Get the ID of current page

		<?php echo get_the_ID(); ?>


21.

//Give the Id of parent page while we are on child page & display 0(zero) we don't have
parent page of current page.

			<?php echo wp_get_post_parent_id(get_the_ID)); ?>


22.

//Display content of div tag only in child page not in parent page.


	<?php 

		if(wp_get_post_parent_id(get_the_ID()){

			<div>
			............
			</div>

		<?php }  ?>


23.

//Get the title of the parent page on child page

	
	$theParent= wp_get_post_parent_id(get_the_ID());

	Back to <?php echo get_the_title($theParent); ?>    //it allows ur to pass the parameter.



24.
// Pont to the url of Parent page of current page.


	<?php echo get_permalink($theParent);  ?>




25. Setting permalink to Custom URL: eg. http://localhost/university/movie-page/

	//the index.php by default in permalink is removed by creating .htaccess file in root of directory.

	WP-Dashboard->Setting->permalink->SELECT Post name option for permalink and save it.


26. Menu of child page link:

		    <?php 


      $testArray= get_pages(array(

        'child_of'=> get_the_ID()
      ));

    if($theParentpage or $testArray){ ?>
    <div class="page-links">
      <h2 class="page-links__title"><a href="<?php echo get_permalink($theParentPage); ?>">

        <?php echo get_the_title($theParentPage); ?></a></h2>
      <ul class="min-list">
        
        <?php 

              if($theParentPage) {

                $findChildrenOf = $theParentPage;
              }
              else{
                $findChildrenOf= get_the_ID();
              }

              wp_list_pages(array(

                'title_li'=>NULL,
                'child_of'=>$findChildrenOf,
                'sort_column'=> 'menu_order'
              ));

          ?>

      </ul>
    </div>
    <?php } ?>



  27.<!-- Setting up language for the site an be changed through WP setting -->



  		<html <?php language_attributes(); ?>>
  		  <head>



28. <!-- Gives the CHARSET using like UTF-8 -->

        <meta charset="<?php bloginfo(); ?>">



29.<!-- Gives the Website mobile friendly view -->

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php wp_head(); ?>
   		 </head>



30.  <!-- Gives body tag a class used in CSS   -->


    	<body <?php body_class(); ?>>


31.  //  Registering Menu in WP Dashboard. The 1st argument is user defined name, 2nd argument is Name that will diplay in WP admin screen is display location while creating menu.

			register_nav_menu('headerMenuLocation', 'Header Menu Location');

			register_nav_menu('footerMenuOne', 'Footer Menu One');

			register_nav_menu('footerMenuTwo', 'Footer Menu Two');


	    <!-- Theme Location points to name where assign name in fucntion.php -->

          <?php 

              wp_nav_menu(array(

                'theme_location'=> 'headerMenuLocation'
              ));
        ?>



         <!-- In footer.php we are pointig to footer menu One name as we given in Function.php -->
              <?php
              wp_nav_menu(array(

                'theme_location'=> 'footerMenuOne'
              ));

              ?>

 32. <ul>

          //Glow Custom menu and is_page is a WP function and about-us argument is slug of the page.
          and 
            Glow menu while we are on child page.wp_get_post_parent_id(0)== 12

            <li <?php if(is_page('about-us') or wp_get_post_parent_id(0)== 12) echo 'class="current-menu-item" ' ?>><a href="<?php echo site_url('/about-us') ?>">About Us</a></li>
            <li><a href="#">Programs</a></li>
            <li><a href="#">Events</a></li>
            <li><a href="#">Campuses</a></li>
            <li><a href="#">Blog</a></li>





            


































































































